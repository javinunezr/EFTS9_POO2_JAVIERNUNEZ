
package Models;

public interface Descuento {
    double aplicarDescuento(double precio);
}
