
package Models;


public class Ventas {
    private String rutCliente;
    private String modeloAdquirido; // Desktop o Laptop
    
    public Ventas(String rutCliente, String modeloAdquirido) {
        this.rutCliente = rutCliente;
        this.modeloAdquirido = modeloAdquirido;
    }

    public String getRutCliente() {
        return rutCliente;
    }

    public void setRutCliente(String rutCliente) {
        this.rutCliente = rutCliente;
    }

    public String getModeloAdquirido() {
        return modeloAdquirido;
    }

    public void setModeloAdquirido(String modeloAdquirido) {
        this.modeloAdquirido = modeloAdquirido;
    }

    
        @Override
    public String toString() {
        return "Venta realizada por el cliente con RUT: " + rutCliente + ", Modelo adquirido: " + modeloAdquirido;
    }
}
