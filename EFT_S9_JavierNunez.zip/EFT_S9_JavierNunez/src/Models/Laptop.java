
package Models;


public class Laptop {
    private String descripcionModelo;
    private String cpu;
    private int discoDuro;
    private int ram;
    private int precioLaptop;
    private float tamanoPantallaPulgadas;
    private String esTouch;
    private int cantidadPuertosUsb;
    
    public Laptop (String descripcionModelo, String cpu, int discoDuro, int precioLaptop, int ram, float tamanoPantallaPulgadas, String esTouch, int cantidadPuertosUsb){
        this.descripcionModelo = descripcionModelo;
        this.cpu = cpu;
        this.discoDuro = discoDuro;
        this.precioLaptop = precioLaptop;
        this.ram = ram;
        this.tamanoPantallaPulgadas = tamanoPantallaPulgadas;
        this.esTouch = esTouch;
        this.cantidadPuertosUsb = cantidadPuertosUsb;
    }

    public String getDescripcionModelo() {
        return descripcionModelo;
    }

    public void setDescripcionModelo(String descripcionModelo) {
        this.descripcionModelo = descripcionModelo;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getDiscoDuro() {
        return discoDuro;
    }

    public void setDiscoDuro(int discoDuro) {
        this.discoDuro = discoDuro;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public int getPrecioLaptop() {
        return precioLaptop;
    }

    public void setPrecioLaptop(int precioLaptop) {
        this.precioLaptop = precioLaptop;
    }

    public float getTamanoPantallaPulgadas() {
        return tamanoPantallaPulgadas;
    }

    public void setTamanoPantallaPulgadas(float tamanoPantallaPulgadas) {
        this.tamanoPantallaPulgadas = tamanoPantallaPulgadas;
    }

    public String getEsTouch() {
        return esTouch;
    }

    public void setEsTouch(String esTouch) {
        this.esTouch = esTouch;
    }

    public int getCantidadPuertosUsb() {
        return cantidadPuertosUsb;
    }

    public void setCantidadPuertosUsb(int cantidadPuertosUsb) {
        this.cantidadPuertosUsb = cantidadPuertosUsb;
    }
    
    
}
