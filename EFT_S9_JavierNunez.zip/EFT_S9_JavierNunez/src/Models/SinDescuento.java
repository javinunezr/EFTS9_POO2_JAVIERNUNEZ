
package Models;

public class SinDescuento implements Descuento {
    @Override
    public double aplicarDescuento(double precio) {
        return precio; // No altera el precio
    }
}
