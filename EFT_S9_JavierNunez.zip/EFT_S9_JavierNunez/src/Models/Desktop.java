
package Models;


public class Desktop {
    private String descripcionModelo;
    private String cpu;
    private int discoDuro;
    private int ram;
    private int precioDesktop;
    private int potenciaFuente;
    private String factorForma;
    
    public Desktop (String descripcionModelo, String cpu, int discoDuro, int precioDesktop, int ram, int potenciaFuente, String factorForma){
        this.descripcionModelo = descripcionModelo;
        this.cpu = cpu;
        this.discoDuro = discoDuro;
        this.precioDesktop = precioDesktop;
        this.ram = ram;
        this.potenciaFuente = potenciaFuente;
        this.factorForma = factorForma;
    }



    public String getDescripcionModelo() {
        return descripcionModelo;
    }

    public void setDescripcionModelo(String descripcionModelo) {
        this.descripcionModelo = descripcionModelo;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getDiscoDuro() {
        return discoDuro;
    }

    public void setDiscoDuro(int discoDuro) {
        this.discoDuro = discoDuro;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public int getPrecioDesktop() {
        return precioDesktop;
    }

    public void setPrecioDesktop(int precioDesktop) {
        this.precioDesktop = precioDesktop;
    }

    public int getPotenciaFuente() {
        return potenciaFuente;
    }

    public void setPotenciaFuente(int potenciaFuente) {
        this.potenciaFuente = potenciaFuente;
    }

    public String getFactorForma() {
        return factorForma;
    }

    public void setFactorForma(String factorForma) {
        this.factorForma = factorForma;
    }
    
    
}
