package Controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import Models.Desktop;
import java.util.List;
import java.util.ArrayList;

public class DesktopController {
    private List<Desktop> desktops;
    private DatabaseConnection databaseconnection;
    
    public DesktopController(){
        desktops = new ArrayList<>();
        databaseconnection = new DatabaseConnection();
    }
    
    // Consulta Desktops
    public List<Desktop> getDesktopsFromDB(){
        List<Desktop> desktops = new ArrayList<>();
        String query = "SELECT * FROM Desktops";
        try{
            Connection connection = databaseconnection.getConnection();
            if (!connection.isClosed()) {
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);

                while (resultSet.next()){
                    String descripcionModelo = resultSet.getString("descripcion_modelo");
                    String cpu = resultSet.getString("cpu");
                    int discoDuro = resultSet.getInt("disco_duro_mb");
                    int ram = resultSet.getInt("ram_gb");
                    int precioDesktop = resultSet.getInt("precio_desktop");
                    int potenciaFuente = resultSet.getInt("potencia_fuente");
                    String factorForma = resultSet.getString("factor_forma");

                    Desktop desktop = new Desktop(descripcionModelo, cpu, discoDuro, precioDesktop, ram, potenciaFuente, factorForma);
                    desktops.add(desktop);
                }
            }
        }    
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener las desktops de la base de datos: " + e.getMessage());
        }   
        return desktops;
    }
    
        //(String descripcionModelo, String cpu, int discoDuro, int precioDesktop, int ram, int potenciaFuente, String factorForma)
    
        public Desktop buscarDesktopPorModelo(String descripcionModelo) {
        String sql = "SELECT * FROM Desktops WHERE descripcion_modelo = ?";
        try (Connection connection = databaseconnection.getConnection()) {
            if (connection == null || connection.isClosed()) {
                System.out.println("La conexión está cerrada o es nula.");
                return null;
            }
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, descripcionModelo);

                
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String cpu = resultSet.getString("cpu");
                    int discoDuro = resultSet.getInt("disco_duro_mb");
                    int precioDesktop = resultSet.getInt("precio_desktop");
                    int ram = resultSet.getInt("ram_gb");
                    int potenciaFuente = resultSet.getInt("potencia_fuente");
                    String factorForma = resultSet.getString("factor_forma");

                
                        return new Desktop(descripcionModelo, cpu, discoDuro, precioDesktop, ram, potenciaFuente, factorForma);

                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al ejecutar la consulta: " + e.getMessage());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al obtener la conexión: " + e.getMessage());
        }
        return null;
    }
    
    
    
    // Insertar Desktop
    public void insertarDesktop(Desktop desktop) throws SQLException{
        String sql = "INSERT INTO Desktops(descripcion_modelo, cpu, disco_duro_mb, ram_gb, precio_desktop, potencia_fuente, factor_forma) VALUES (?,?,?,?,?,?,?)";
        Connection connection = databaseconnection.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setString(1, desktop.getDescripcionModelo());
            statement.setString(2, desktop.getCpu());
            statement.setInt(3, desktop.getDiscoDuro());
            statement.setInt(4, desktop.getRam());
            statement.setInt(5, desktop.getPrecioDesktop());
            statement.setInt(6, desktop.getPotenciaFuente());
            statement.setString(7, desktop.getFactorForma());
            statement.executeUpdate();
            System.out.println("Desktop ingresada con éxito");
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al insertar la desktop: " + e.getMessage());
        }   
    }
    
    // Eliminar Desktop
    public boolean eliminarDesktop(String descripcionModelo) throws SQLException{
        String sql = "DELETE FROM Desktops WHERE descripcion_modelo = (?)";
        Connection connection = databaseconnection.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setString(1, descripcionModelo);
            statement.executeUpdate();
            System.out.println("Desktop eliminada con éxito");
            return true;
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al eliminar la desktop: " + e.getMessage());
        }   
        return false;
    }

    // Actualizar Desktop
    public boolean actualizarDesktop(String descripcionModelo, String cpu, int discoDuro, int precioDesktop, int ram, int potenciaFuente, String factorForma) {
        String sql = "UPDATE Desktops SET cpu = ?, disco_duro_mb = ?, precio_desktop = ?, ram_gb = ?, potencia_fuente = ?, factor_forma = ? WHERE descripcion_modelo = ?";

        try (Connection connection = databaseconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, cpu);
            statement.setInt(2, discoDuro);
            statement.setInt(3, precioDesktop);
            statement.setInt(4, ram);
            statement.setInt(5, potenciaFuente);
            statement.setString(6, factorForma);
            statement.setString(7, descripcionModelo);

            int filasActualizadas = statement.executeUpdate();

            if (filasActualizadas > 0) {
                System.out.println("Desktop actualizada con éxito.");
                return true;
            } else {
                System.out.println("No se encontró la desktop especificada.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al actualizar la desktop: " + e.getMessage());
            return false;
        }
    }
}

