
package Controllers;

import Models.Ventas;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;


public class VentasController {
    private List<Ventas> ventasBD;    
    private DatabaseConnection databaseconnection;

    public VentasController() {
        ventasBD = new ArrayList<>();        
        databaseconnection = new DatabaseConnection();
    }

    // Registrar una nueva venta
public void registrarVenta(Ventas ventasBD) throws SQLException {
    String sql = "INSERT INTO Ventas(rut_cliente, modelo_adquirido) VALUES (?,?)";
    Connection connection = databaseconnection.getConnection();
    PreparedStatement statement = connection.prepareStatement(sql);
    try {
        statement.setString(1, ventasBD.getRutCliente());
        statement.setString(2, ventasBD.getModeloAdquirido());
        statement.executeUpdate();
        System.out.println("Venta registrada con éxito");
    } catch (SQLException e) {
        e.printStackTrace();
        System.out.println("Error al registrar venta: " + e.getMessage());
    }   
}

    // Mostrar todas las ventas registradas
    public List<Ventas> obtenerVentas() {
        return ventasBD;
    }
    
}
