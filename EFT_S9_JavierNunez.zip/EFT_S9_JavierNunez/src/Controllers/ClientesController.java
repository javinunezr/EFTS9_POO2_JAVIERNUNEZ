
package Controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import Models.Clientes;
import java.util.List;
import java.util.ArrayList;



public class ClientesController {
    private List<Clientes> clientesBD;
    private DatabaseConnection databaseconnection;
    
    public ClientesController(){
        clientesBD = new ArrayList<>();
        databaseconnection = new DatabaseConnection();
    }
    
    //(String rut, String nombreCompleto, String direccion, String comuna, String correoElectronico, String telefono)
    
    
    // Consulta Clientes
    public List<Clientes> getClientesFromDB(){
        List<Clientes> clientesBD = new ArrayList<>();
        String query = "SELECT * FROM Clientes";
        try{
            Connection connection = databaseconnection.getConnection();
            if (!connection.isClosed()) {
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);

                while (resultSet.next()){
                    String rut = resultSet.getString("rut");
                    String nombreCompleto = resultSet.getString("nombre_completo");
                    String direccion = resultSet.getString("direccion");
                    String comuna = resultSet.getString("comuna");
                    String correoElectronico = resultSet.getString("correo_electronico");
                    String telefono = resultSet.getString("telefono");

                    Clientes clientes = new Clientes(rut, nombreCompleto, direccion, comuna, correoElectronico, telefono);
                    clientesBD.add(clientes);
                }
            }
        }    
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener los clientes de la base de datos: " + e.getMessage());
        }   
        return clientesBD;
    }
    
            //(String rut, String nombreCompleto, String direccion, String comuna, String correoElectronico, String telefono)
    
        public Clientes buscarClientesPorRut(String rut) {
        String sql = "SELECT * FROM Clientes WHERE rut = ?";
        try (Connection connection = databaseconnection.getConnection()) {
            if (connection == null || connection.isClosed()) {
                System.out.println("La conexión está cerrada o es nula.");
                return null;
            }
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, rut);

                
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String nombreCompleto = resultSet.getString("nombre_completo");
                    String direccion = resultSet.getString("direccion");
                    String comuna = resultSet.getString("comuna");
                    String correoElectronico = resultSet.getString("correo_electronico");
                    String telefono = resultSet.getString("telefono");

                
                        return new Clientes(rut, nombreCompleto, direccion, comuna, correoElectronico, telefono);

                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al ejecutar la consulta: " + e.getMessage());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al obtener la conexión: " + e.getMessage());
        }
        return null;
    }
    
    
    
    // Insertar Cientes
    public void insertarClientes(Clientes clientesBD) throws SQLException{
        String sql = "INSERT INTO Clientes(rut, nombre_completo, direccion, comuna, correo_electronico, telefono) VALUES (?,?,?,?,?,?)";
        Connection connection = databaseconnection.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setString(1, clientesBD.getRut());
            statement.setString(2, clientesBD.getNombreCompleto());
            statement.setString(3, clientesBD.getDireccion());
            statement.setString(4, clientesBD.getComuna());
            statement.setString(5, clientesBD.getCorreoElectronico());
            statement.setString(6, clientesBD.getTelefono());
            statement.executeUpdate();
            System.out.println("Cliente ingresado con éxito");
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al insertar cliente: " + e.getMessage());
        }   
    }
    
    // Eliminar Cliente
    public boolean eliminarClientes(String rut) throws SQLException{
        String sql = "DELETE FROM Clientes WHERE rut = (?)";
        Connection connection = databaseconnection.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setString(1, rut);
            statement.executeUpdate();
            System.out.println("Cliente eliminado con éxito");
            return true;
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al eliminar cliente: " + e.getMessage());
        }   
        return false;
    }

    // Actualizar Cliente
    public boolean actualizarClientes(String rut, String nombreCompleto, String direccion, String comuna, String correoElectronico, String telefono) {
        String sql = "UPDATE Clientes SET nombre_completo = ?, direccion= ?, comuna = ?, correo_electronico = ?, telefono = ? WHERE rut = ?";

        try (Connection connection = databaseconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, nombreCompleto);
            statement.setString(2, direccion);
            statement.setString(3, comuna);
            statement.setString(4, correoElectronico);
            statement.setString(5, telefono);
            statement.setString(6, rut);

            int filasActualizadas = statement.executeUpdate();

            if (filasActualizadas > 0) {
                System.out.println("Cliente actualizado con éxito.");
                return true;
            } else {
                System.out.println("No se encontró el cliente especificada.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al actualizar cliente: " + e.getMessage());
            return false;
        }
    }
}

