package Controllers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import Models.Laptop;
import java.util.List;
import java.util.ArrayList;

public class LaptopController {
    private List<Laptop> laptops;
    private DatabaseConnection databaseconnection;
    
    public LaptopController(){
        laptops = new ArrayList<>();
        databaseconnection = new DatabaseConnection();
    }
    
    // Consulta Laptops
    public List<Laptop> getLaptopsFromDB(){
        List<Laptop> laptops = new ArrayList<>();
        String query = "SELECT * FROM Laptops";
        try{
            Connection connection = databaseconnection.getConnection();
            if (!connection.isClosed()) {
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);

                while (resultSet.next()){
                    String descripcionModelo = resultSet.getString("descripcion_modelo");
                    String cpu = resultSet.getString("cpu");
                    int discoDuro = resultSet.getInt("disco_duro_mb");
                    int ram = resultSet.getInt("ram_gb");
                    int precioLaptop = resultSet.getInt("precio_laptop");
                    float tamanoPantallaPulgadas = resultSet.getFloat("tamano_pantalla_pulgadas");
                    String esTouch = resultSet.getString("es_touch");
                    int cantidadPuertosUsb = resultSet.getInt("cantidad_puertos_usb");

                    Laptop laptop = new Laptop(descripcionModelo, cpu, discoDuro, precioLaptop, ram, tamanoPantallaPulgadas, esTouch, cantidadPuertosUsb);
                    laptops.add(laptop);
                }
            }
        }    
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener las laptops de la base de datos: " + e.getMessage());
        }   
        return laptops;
    }
    
    
    
            //(String descripcionModelo, String cpu, int discoDuro, int precioLaptop, int ram, float tamanoPantallaPulgadas, String esTouch, int cantidadPuertosUsb
    public Laptop buscarLaptopPorModelo(String descripcionModelo) {
        String sql = "SELECT * FROM Laptops WHERE descripcion_modelo = ?";
        try (Connection connection = databaseconnection.getConnection()) {
            if (connection == null || connection.isClosed()) {
                System.out.println("La conexión está cerrada o es nula.");
                return null;
            }
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, descripcionModelo);

                
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String cpu = resultSet.getString("cpu");
                    int discoDuro = resultSet.getInt("disco_duro_mb");
                    int precioLaptop = resultSet.getInt("precio_laptop");
                    int ram = resultSet.getInt("ram_gb");
                    float tamanoPantallaPulgadas = resultSet.getFloat("tamano_pantalla_pulgadas");
                    String esTouch = resultSet.getString("es_touch");
                    int cantidadPuertosUsb = resultSet.getInt("cantidad_puertos_usb");

                
                        return new Laptop(descripcionModelo, cpu, discoDuro, precioLaptop, ram, tamanoPantallaPulgadas, esTouch, cantidadPuertosUsb);

                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al ejecutar la consulta: " + e.getMessage());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al obtener la conexión: " + e.getMessage());
        }
        return null;
    }
    
    
    
    
    // Insertar Laptop
    public void insertarLaptop(Laptop laptop) throws SQLException{
        String sql = "INSERT INTO Laptops(descripcion_modelo, cpu, disco_duro_mb, ram_gb, precio_laptop, tamano_pantalla_pulgadas, es_touch, cantidad_puertos_usb) VALUES (?,?,?,?,?,?,?,?)";
        Connection connection = databaseconnection.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setString(1, laptop.getDescripcionModelo());
            statement.setString(2, laptop.getCpu());
            statement.setInt(3, laptop.getDiscoDuro());
            statement.setInt(4, laptop.getRam());
            statement.setInt(5, laptop.getPrecioLaptop());
            statement.setFloat(6, laptop.getTamanoPantallaPulgadas());
            statement.setString(7, laptop.getEsTouch());
            statement.setInt(8, laptop.getCantidadPuertosUsb());
            statement.executeUpdate();
            System.out.println("Laptop ingresada con éxito");
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al insertar la laptop: " + e.getMessage());
        }   
    }
    
    // Eliminar Laptop
    public boolean eliminarLaptop(String descripcionModelo) throws SQLException{
        String sql = "DELETE FROM Laptops WHERE descripcion_modelo = (?)";
        Connection connection = databaseconnection.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setString(1, descripcionModelo);
            statement.executeUpdate();
            System.out.println("Laptop eliminada con éxito");
            return true;
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al eliminar la laptop: " + e.getMessage());
        }   
        return false;
    }

    // Actualizar Laptop
    public boolean actualizarLaptop(String descripcionModelo, String cpu, int discoDuro, int ram, int precioLaptop, float tamanoPantallaPulgadas, String esTouch, int cantidadPuertosUsb) {
        String sql = "UPDATE Laptops SET cpu = ?, disco_duro_mb = ?, ram_gb = ?, precio_laptop = ?, tamano_pantalla_pulgadas = ?, es_touch = ?, cantidad_puertos_usb = ? WHERE descripcion_modelo = ?";

        try (Connection connection = databaseconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, cpu);
            statement.setInt(2, discoDuro);
            statement.setInt(3, ram);
            statement.setInt(4, precioLaptop);
            statement.setFloat(5, tamanoPantallaPulgadas);
            statement.setString(6, esTouch);
            statement.setInt(7, cantidadPuertosUsb);
            statement.setString(8, descripcionModelo);

            int filasActualizadas = statement.executeUpdate();

            if (filasActualizadas > 0) {
                System.out.println("Laptop actualizada con éxito.");
                return true;
            } else {
                System.out.println("No se encontró la laptop especificada.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al actualizar la laptop: " + e.getMessage());
            return false;
        }
    }
}
